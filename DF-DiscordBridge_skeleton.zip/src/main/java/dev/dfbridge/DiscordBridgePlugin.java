package dev.dfbridge;

import dev.dfbridge.listeners.AnnounceListener;
import org.bukkit.Bukkit;
import org.bukkit.plugin.java.JavaPlugin;

public final class DiscordBridgePlugin extends JavaPlugin {

    @Override
    public void onEnable() {
        saveDefaultConfig();
        getLogger().info("[DF-DiscordBridge] Enabling...");

        // Warn if DiscordSRV is not present (we use reflection at runtime)
        if (Bukkit.getPluginManager().getPlugin("DiscordSRV") == null) {
            getLogger().warning("[DF-DiscordBridge] DiscordSRV not found. Messages won't be delivered until it's installed/enabled.");
        }

        // Register event listener
        Bukkit.getPluginManager().registerEvents(new AnnounceListener(this), this);

        getLogger().info("[DF-DiscordBridge] Ready.");
    }

    @Override
    public void onDisable() {
        getLogger().info("[DF-DiscordBridge] Disabled.");
    }
}
