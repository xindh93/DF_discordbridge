package dev.dfbridge.listeners;

import dev.dfbridge.DiscordBridgePlugin;
import dev.dfbridge.events.DFAnnounceEvent;
import dev.dfbridge.util.GlobMatcher;
import dev.dfbridge.util.MessageFormatter;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;

import java.lang.reflect.Method;
import java.util.List;
import java.util.Map;
import java.util.Objects;

public final class AnnounceListener implements Listener {
    private final DiscordBridgePlugin plugin;

    public AnnounceListener(DiscordBridgePlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onAnnounce(DFAnnounceEvent event) {
        FileConfiguration cfg = plugin.getConfig();
        String channelId = cfg.getString("discord.channel-id", "");
        if (channelId == null || channelId.isEmpty()) {
            plugin.getLogger().warning("[DF-DiscordBridge] 'discord.channel-id' is not set.");
            return;
        }

        // Resolve template by type path: messages.<typePath>.template
        String[] parts = event.getType().split("\\.");
        String template = null;
        ConfigurationSection msg = cfg.getConfigurationSection("messages");
        if (msg != null) {
            ConfigurationSection cursor = msg;
            for (String p : parts) {
                cursor = cursor.getConfigurationSection(p);
                if (cursor == null) break;
            }
            if (cursor != null) template = cursor.getString("template");
            if (template == null) {
                ConfigurationSection def = msg.getConfigurationSection("default");
                if (def != null) template = def.getString("template", "{player}: {type}");
            }
        } else {
            template = "{player}: {type}";
        }

        Map<String, String> data = event.getData();
        ConfigurationSection roles = cfg.getConfigurationSection("roles");
        String result = MessageFormatter.render(template, data, roles);

        // Apply prefix-groups (e.g., @everyone) if patterns match
        if (msg != null) {
            ConfigurationSection pgRoot = msg.getConfigurationSection("prefix-groups");
            if (pgRoot != null) {
                for (String name : pgRoot.getKeys(false)) {
                    ConfigurationSection entry = pgRoot.getConfigurationSection(name);
                    if (entry == null) continue;
                    List<String> patterns = entry.getStringList("matches");
                    String text = entry.getString("text", "");
                    if (patterns != null) {
                        for (String pat : patterns) {
                            if (GlobMatcher.matches(pat, event.getType())) {
                                result = text + result;
                                break;
                            }
                        }
                    }
                }
            }
        }

        sendToDiscord(channelId, result);
    }

    private void sendToDiscord(String channelId, String content) {
        try {
            Class<?> dsrvClass = Class.forName("github.scarsz.discordsrv.DiscordSRV");
            Method getPlugin = dsrvClass.getMethod("getPlugin");
            Object dsrv = getPlugin.invoke(null);
            if (dsrv == null) {
                plugin.getLogger().warning("[DF-DiscordBridge] DiscordSRV is not ready.");
                return;
            }
            Method getMainGuild = dsrv.getClass().getMethod("getMainGuild");
            Object guild = getMainGuild.invoke(dsrv);
            if (guild == null) {
                plugin.getLogger().warning("[DF-DiscordBridge] DiscordSRV getMainGuild() returned null.");
                return;
            }
            // getTextChannelById(long)
            Method getTextChannelById = guild.getClass().getMethod("getTextChannelById", long.class);
            Object channel = getTextChannelById.invoke(guild, Long.parseLong(channelId));
            if (channel == null) {
                plugin.getLogger().warning("[DF-DiscordBridge] Channel not found: " + channelId);
                return;
            }
            // sendMessage(String) -> returns RestAction
            Method sendMessage = channel.getClass().getMethod("sendMessage", CharSequence.class);
            Object action = sendMessage.invoke(channel, content);
            // queue()
            Method queue = action.getClass().getMethod("queue");
            queue.invoke(action);
        } catch (ClassNotFoundException e) {
            plugin.getLogger().warning("[DF-DiscordBridge] DiscordSRV class not found. Is the jar installed?");
        } catch (Exception e) {
            plugin.getLogger().warning("[DF-DiscordBridge] Failed to send message via DiscordSRV: " + e.getClass().getSimpleName() + ": " + e.getMessage());
        }
    }
}
