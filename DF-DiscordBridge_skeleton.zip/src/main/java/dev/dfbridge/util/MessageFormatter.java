package dev.dfbridge.util;

import org.bukkit.configuration.ConfigurationSection;

import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class MessageFormatter {
    private MessageFormatter() {}

    private static final Pattern ROLE_PATTERN = Pattern.compile("\\{role:([^}]+)\\}");
    private static final Pattern VAR_PATTERN = Pattern.compile("\\{([a-zA-Z0-9_]+)\\}");

    public static String render(String template, Map<String, String> data, ConfigurationSection rolesSection) {
        if (template == null) template = "";
        String result = template;

        // {role:KEY} -> <@&ROLEID>
        Matcher rm = ROLE_PATTERN.matcher(result);
        StringBuffer sb = new StringBuffer();
        while (rm.find()) {
            String key = rm.group(1);
            String roleId = rolesSection != null ? rolesSection.getString(key) : null;
            String replacement = roleId != null && !roleId.isEmpty() ? "<@&" + roleId + ">" : "";
            rm.appendReplacement(sb, Matcher.quoteReplacement(replacement));
        }
        rm.appendTail(sb);
        result = sb.toString();

        // {everyone} -> @everyone
        result = result.replace("{everyone}", "@everyone");

        // {var} replacements
        Matcher vm = VAR_PATTERN.matcher(result);
        sb = new StringBuffer();
        while (vm.find()) {
            String key = vm.group(1);
            String replacement = data != null ? data.getOrDefault(key, "") : "";
            vm.appendReplacement(sb, Matcher.quoteReplacement(replacement));
        }
        vm.appendTail(sb);
        result = sb.toString();

        return result;
    }
}
